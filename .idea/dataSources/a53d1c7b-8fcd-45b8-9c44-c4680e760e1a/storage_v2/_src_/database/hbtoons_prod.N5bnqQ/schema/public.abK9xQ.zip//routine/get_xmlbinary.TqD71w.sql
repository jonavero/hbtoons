create function get_xmlbinary()
  returns character varying
language plpgsql
as $$
DECLARE
                      xmlbin varchar;
                    BEGIN
                      select into xmlbin setting from pg_settings where name='xmlbinary';
                      RETURN xmlbin;
                    END;
$$;

