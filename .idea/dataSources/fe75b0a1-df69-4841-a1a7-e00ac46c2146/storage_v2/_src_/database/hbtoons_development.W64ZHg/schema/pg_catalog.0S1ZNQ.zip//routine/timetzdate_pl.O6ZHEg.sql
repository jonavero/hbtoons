create function timetzdate_pl(time with time zone, date)
  returns timestamp with time zone
immutable
strict
cost 1
language sql
as $$
select ($2 + $1)
$$;

