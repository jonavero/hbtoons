
// $('#enviar').click(function(){
//   var nombre = $("#nombre").attr('value');
//   console.log(nombre);
//
// });




